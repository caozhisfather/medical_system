from __future__ import annotations

import json
import time
import uuid
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from ..config import settings


class DigitalHumanService:
    """Stable app-facing adapter for the optional LiveAct sidecar."""

    def __init__(self) -> None:
        self.sessions: dict[str, dict[str, str]] = {}

    def create_session(self, role: str, avatar_id: str) -> dict[str, str]:
        session_id = f"dh-{uuid.uuid4().hex[:12]}"
        self.sessions[session_id] = {
            "role": role,
            "avatar_id": avatar_id,
            "state": "idle",
            "detail": "",
        }
        return {
            "session_id": session_id,
            "role": role,
            "avatar_id": avatar_id,
            "state": "idle",
        }

    def update_status(self, session_id: str, state: str, detail: str) -> dict[str, str]:
        session = self.sessions.setdefault(
            session_id,
            {"role": "student", "avatar_id": settings.liveact_avatar_id},
        )
        session.update({"state": state, "detail": detail})
        return {"session_id": session_id, "state": state, "detail": detail}

    def modes(self) -> dict[str, Any]:
        health = self._request("GET", "/health") if settings.digital_human_mode == "liveact" else None
        liveact_available = bool(health and health.get("ready_for_liveact"))
        return {
            "status": "ok",
            "active_mode": "liveact" if liveact_available else "mock",
            "configured_mode": settings.digital_human_mode,
            "liveact_available": liveact_available,
            "liveact_service_url": settings.liveact_service_url,
        }

    def acceleration_status(self) -> dict[str, Any]:
        status = self._request("GET", "/kernel-health")
        return status or {
            "status": "fallback",
            "selected_backend": "cpu-mock",
            "notes": ["LiveAct sidecar is unavailable; the teaching demo remains usable."],
        }

    def speak(self, payload: dict[str, Any]) -> dict[str, Any]:
        requested_liveact = payload.get("mode") == "liveact"
        if requested_liveact and settings.digital_human_mode == "liveact":
            response = self._request("POST", "/speak", payload)
            if response:
                return response
            return self._mock_speak(payload, "LiveAct service is unavailable.")
        return self._mock_speak(payload)

    def mock_video(self, state: str, avatar_id: str) -> dict[str, Any]:
        return {
            "status": "ok",
            "mode": "mock",
            "state": state,
            "avatar_id": avatar_id,
            "video_url": None,
            "poster_url": "/assets/medical-tutor-BBOP_nMH.png",
            "provider": "local-digital-human-demo",
        }

    def _mock_speak(self, payload: dict[str, Any], reason: str | None = None) -> dict[str, Any]:
        text = str(payload.get("text", ""))
        action = str(payload.get("action", "explain"))
        emotion = str(payload.get("emotion", "teaching"))
        state = self._state(action, emotion)
        session_id = str(payload.get("session_id", "demo-session-001"))
        self.update_status(session_id, state, text)
        return {
            "status": "fallback" if reason else "ok",
            "session_id": session_id,
            "request_id": f"mock-{uuid.uuid4().hex[:10]}",
            "mode": "mock",
            "state": state,
            "video_url": None,
            "stream_url": None,
            "poster_url": "/assets/medical-tutor-BBOP_nMH.png",
            "subtitle": text,
            "emotion": emotion,
            "action": action,
            "duration": round(max(2.5, min(22.0, len(text) / 5.2)), 1),
            "provider": "local-digital-human-demo",
            "fallback_reason": reason,
            "generated_at": int(time.time()),
        }

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload else None
        request = Request(
            f"{settings.liveact_service_url.rstrip('/')}{path}",
            data=body,
            headers={"Content-Type": "application/json"},
            method=method,
        )
        try:
            with urlopen(request, timeout=settings.liveact_request_timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            return None

    @staticmethod
    def _state(action: str, emotion: str) -> str:
        combined = f"{action} {emotion}".lower()
        if any(token in combined for token in ("warning", "warn", "risk", "alert")):
            return "warning"
        if any(token in combined for token in ("score", "scoring", "evaluate")):
            return "scoring"
        if "listen" in combined:
            return "listening"
        return "speaking"
