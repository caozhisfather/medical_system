from __future__ import annotations

import json
from pathlib import Path
from typing import Any


ROOT_DIR = Path(__file__).resolve().parents[2]
GRAPH_FILE = ROOT_DIR / "data" / "medical_kg_bilingual.json"


class TranslationService:
    def __init__(self) -> None:
        graph = json.loads(GRAPH_FILE.read_text(encoding="utf-8"))
        self.nodes: list[dict[str, Any]] = graph.get("nodes", [])

    def search_terms(self, query: str, limit: int = 12) -> list[dict[str, Any]]:
        normalized = query.strip().lower()
        ranked: list[tuple[int, dict[str, Any]]] = []

        for node in self.nodes:
            labels = [
                node.get("label_zh", ""),
                node.get("label_en", ""),
                *node.get("aliases_zh", []),
                *node.get("aliases_en", []),
            ]
            searchable = " ".join(str(label) for label in labels if label).lower()
            score = 0
            if normalized and normalized in searchable:
                score += 3
            score += sum(1 for token in normalized.split() if token and token in searchable)
            if score:
                ranked.append((score, node))

        ranked.sort(key=lambda item: item[0], reverse=True)
        return [self._term(node) for _, node in ranked[:limit]]

    @staticmethod
    def _term(node: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": node.get("id", ""),
            "type": node.get("type") or node.get("group", "Term"),
            "label_zh": node.get("label_zh") or node.get("label", ""),
            "label_en": node.get("label_en") or node.get("label", ""),
            "aliases_zh": node.get("aliases_zh", []),
            "aliases_en": node.get("aliases_en", []),
        }
