<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import {
  Activity, AlertTriangle, BarChart3, Bell, BookOpen, Bot, BrainCircuit,
  Check, ChevronRight, CircleHelp, ClipboardCheck, FileText, GitBranch,
  GraduationCap, LayoutDashboard, Menu, MessageSquareText, Play, RotateCcw,
  Search, Send, ShieldCheck, Sparkles, Stethoscope, UserRound, Users, X
} from 'lucide-vue-next';
import {
  getCases, getGuidelines, getKnowledgeGraph, getOverview, getTeacherDashboard,
  getTrainingReport, getWorkflow, sendPatientMessage
} from './api';
import type {
  CaseSummary, ChatMessage, GuidelineDoc, KnowledgeEdge, KnowledgeNode,
  MissingPoint, Overview, PatientChatResponse, ScoreItem, TeacherDashboard,
  TrainingReport, WorkflowStage
} from './types';

type ViewName = 'training' | 'guidelines' | 'workflow' | 'teacher' | 'report' | 'graph';

const useBackend = Boolean(import.meta.env.VITE_API_BASE_URL);
const role = ref<'student' | 'teacher'>('student');
const activeView = ref<ViewName>('training');
const mobileNavOpen = ref(false);
const activeCaseId = ref('emergency_chest_pain');
const caseQuery = ref('');
const input = ref('请问您的胸痛是什么性质？有没有向左肩或后背放射？');
const loading = ref(false);
const error = ref('');
const scoreTab = ref<'scores' | 'missing'>('scores');
const overview = ref<Overview | null>(null);
const cases = ref<CaseSummary[]>([]);
const messages = ref<ChatMessage[]>([
  { role: 'patient', content: '医生，我胸口疼得厉害，大概两个小时前开始的。' },
  { role: 'tutor', content: '先围绕胸痛性质、部位、持续时间、诱因、伴随症状和危险因素进行结构化问诊。' }
]);
const scores = ref<ScoreItem[]>([]);
const missing = ref<MissingPoint[]>([]);
const citations = ref<GuidelineDoc[]>([]);
const workflow = ref<WorkflowStage[]>([]);
const dashboard = ref<TeacherDashboard | null>(null);
const report = ref<TrainingReport | null>(null);
const kgNodes = ref<KnowledgeNode[]>([]);
const kgEdges = ref<KnowledgeEdge[]>([]);

const navItems = [
  { id: 'training' as const, label: '实训工作台', icon: Stethoscope },
  { id: 'guidelines' as const, label: '指南证据库', icon: BookOpen },
  { id: 'workflow' as const, label: 'Agent 流程', icon: GitBranch },
  { id: 'teacher' as const, label: '教学看板', icon: BarChart3 },
  { id: 'report' as const, label: '训练报告', icon: ClipboardCheck },
  { id: 'graph' as const, label: '知识图谱', icon: BrainCircuit }
];

const viewMeta: Record<ViewName, { title: string; subtitle: string }> = {
  training: { title: '临床思维实训', subtitle: '与 AI 标准化病人对话，获得实时过程反馈' },
  guidelines: { title: '指南证据库', subtitle: '可追溯的医学指南、教材与专家共识' },
  workflow: { title: '多智能体工作流', subtitle: '查看每一次反馈背后的模型协作链路' },
  teacher: { title: '教学数据看板', subtitle: '从班级共性薄弱点定位下一步教学重点' },
  report: { title: '个人训练报告', subtitle: '复盘诊断路径，形成可执行的能力提升计划' },
  graph: { title: '医学知识图谱', subtitle: '连接症状、疾病、检查、指南与学习目标' }
};

const fallbackOverview: Overview = {
  name: '临思智训',
  subtitle: 'AI 标准化病人临床思维训练平台',
  contest_track: 'AI + 医学教育',
  positioning: '以多智能体协作、RAG 指南循证和过程性评分，构建临床思维训练闭环。',
  metrics: [
    { label: '虚拟病例', value: '5', trend: '覆盖核心临床场景' },
    { label: '评分维度', value: '6', trend: '全过程能力评估' },
    { label: 'Agent 节点', value: '5', trend: '协同生成与校验' },
    { label: '循证来源', value: '3类', trend: '指南、教材、共识' }
  ],
  scenarios: ['学生端', '教师端']
};

const fallbackCases: CaseSummary[] = [
  { id: 'emergency_chest_pain', title: '急诊胸痛', department: '急诊医学', chief_complaint: '胸痛 2 小时', difficulty: '中级', learning_goals: ['胸痛问诊结构', '急性冠脉综合征识别', '危重鉴别诊断', '检查选择'] },
  { id: 'acute_abdominal_pain', title: '急性腹痛', department: '消化与急诊', chief_complaint: '右下腹痛 6 小时', difficulty: '初中级', learning_goals: ['腹痛定位', '外科急腹症识别', '伴随症状问诊'] },
  { id: 'fever_unknown', title: '发热待查', department: '感染与内科', chief_complaint: '反复发热 3 天', difficulty: '中级', learning_goals: ['热型问诊', '感染灶定位', '用药史采集'] },
  { id: 'dyspnea', title: '呼吸困难', department: '呼吸与急诊', chief_complaint: '活动后气促加重', difficulty: '中级', learning_goals: ['呼吸困难分层', '心肺鉴别', '低氧风险识别'] },
  { id: 'diabetes_education', title: '糖尿病健康宣教', department: '全科医学', chief_complaint: '血糖控制不佳', difficulty: '初级', learning_goals: ['健康宣教', '用药依从性', '生活方式干预'] }
];

const fallbackGuidelines: GuidelineDoc[] = [
  { id: 'chest_pain_primary', title: '《急性胸痛基层诊疗指南》', source: '中华全科医师杂志', type: '临床指南', tags: ['胸痛', '急诊', '心电图'], content: '急性胸痛评估应关注疼痛性质、持续时间、诱因、放射痛、伴随症状和心血管危险因素。' },
  { id: 'acs_guideline', title: '《急性冠脉综合征诊疗指南》', source: '中华心血管病杂志', type: '专家共识', tags: ['ACS', '肌钙蛋白'], content: '急性冠脉综合征评估需要结合症状、心电图动态变化和心肌损伤标志物结果。' },
  { id: 'diagnostics_chest_pain', title: '《临床诊断学》胸痛章节', source: '医学教育示范教材', type: '教材', tags: ['问诊', '胸痛性质'], content: '胸痛问诊包括部位、性质、程度、持续时间、诱发缓解因素、放射部位和伴随症状。' }
];

const fallbackWorkflow: WorkflowStage[] = [
  { id: 'patient', name: '病人应答生成', agent: 'PatientAgent', goal: '根据病例脚本与对话历史模拟标准化病人回答。' },
  { id: 'retrieval', name: '循证知识检索', agent: 'RetrievalAgent', goal: '从指南、教材和专家共识中检索相关证据。' },
  { id: 'scoring', name: '临床思维评分', agent: 'ScoringAgent', goal: '对病史采集、鉴别诊断等六个维度进行评分。' },
  { id: 'safety', name: '医学安全校验', agent: 'SafetyAgent', goal: '检测诊断泄露、证据冲突与不安全的医疗建议。' },
  { id: 'report', name: '训练报告生成', agent: 'ReportAgent', goal: '生成能力画像、改进建议和下一病例推荐。' }
];

const fallbackDashboard: TeacherDashboard = {
  class_average: 82,
  training_sessions: 248,
  teacher_time_saved: '41%',
  citation_accuracy: '88%',
  improvements: [
    { label: '临床推理得分提升', value: 24 },
    { label: '关键问诊遗漏率下降', value: 32 },
    { label: '指南引用准确率提升', value: 18 }
  ],
  common_missing_points: ['未询问胸痛性质', '未主动排除主动脉夹层', '未及时申请心电图与肌钙蛋白', '危险因素记录不完整']
};

const fallbackReport: TrainingReport = {
  case_id: 'emergency_chest_pain',
  diagnosis_path: ['识别胸痛主诉', '采集 ACS 危险因素', '补充高危鉴别', '选择心电图与肌钙蛋白', '根据证据更新诊断路径'],
  strengths: ['能够关注胸痛持续时间和活动诱因', '能将急性冠脉综合征列为重点鉴别'],
  improvements: ['更早询问胸痛性质和放射痛', '主动排除主动脉夹层与肺栓塞', '明确检查依据和教学边界'],
  recommended_cases: ['呼吸困难', '急性腹痛', '发热待查'],
  citations: fallbackGuidelines.map((doc) => ({ id: doc.id, title: doc.title, source: doc.source, snippet: doc.content }))
};

const fallbackGraph = {
  nodes: [
    { id: 'chest_pain', label: '胸痛', group: 'symptom' },
    { id: 'acs', label: '急性冠脉综合征', group: 'disease' },
    { id: 'aortic_dissection', label: '主动脉夹层', group: 'differential' },
    { id: 'pulmonary_embolism', label: '肺栓塞', group: 'differential' },
    { id: 'ecg', label: '心电图', group: 'exam' },
    { id: 'troponin', label: '肌钙蛋白', group: 'exam' },
    { id: 'guideline', label: '指南证据', group: 'guideline' },
    { id: 'learning_goal', label: '学习目标', group: 'learning' }
  ],
  edges: [
    { source: 'chest_pain', target: 'acs', relation: '提示' },
    { source: 'acs', target: 'ecg', relation: '需要检查' },
    { source: 'acs', target: 'troponin', relation: '需要检查' },
    { source: 'chest_pain', target: 'aortic_dissection', relation: '鉴别' },
    { source: 'chest_pain', target: 'pulmonary_embolism', relation: '鉴别' },
    { source: 'guideline', target: 'learning_goal', relation: '支撑' }
  ]
};

const activeCase = computed(() => cases.value.find((item) => item.id === activeCaseId.value) ?? fallbackCases[0]);
const currentOverview = computed(() => overview.value ?? fallbackOverview);
const currentDashboard = computed(() => dashboard.value ?? fallbackDashboard);
const currentReport = computed(() => report.value ?? fallbackReport);
const filteredCases = computed(() => {
  const keyword = caseQuery.value.trim().toLowerCase();
  if (!keyword) return cases.value;
  return cases.value.filter((item) => `${item.title}${item.department}${item.chief_complaint}`.toLowerCase().includes(keyword));
});
const averageScore = computed(() => scores.value.length ? Math.round(scores.value.reduce((sum, item) => sum + item.score, 0) / scores.value.length) : 0);
const currentStage = computed(() => Math.min(messages.value.filter((item) => item.role === 'student').length + 1, 4));
const quickPrompts = ['疼痛是什么性质？', '有没有向肩背部放射？', '是否伴有出汗或恶心？', '既往有高血压或吸烟史吗？'];

const graphNodes = computed(() => {
  const list = kgNodes.value.length ? kgNodes.value : fallbackGraph.nodes;
  return list.map((node, index) => {
    const angle = (Math.PI * 2 * index) / list.length - Math.PI / 2;
    const radius = node.id === 'chest_pain' ? 0 : 170;
    return { ...node, x: 300 + Math.cos(angle) * radius, y: 210 + Math.sin(angle) * radius };
  });
});
const graphEdges = computed(() => kgEdges.value.length ? kgEdges.value : fallbackGraph.edges);

function locate(id: string) {
  return graphNodes.value.find((node) => node.id === id) ?? graphNodes.value[0];
}

function switchView(view: ViewName) {
  activeView.value = view;
  mobileNavOpen.value = false;
}

function localPatientReply(text: string): PatientChatResponse {
  const reply = text.includes('性质') || text.includes('怎么疼')
    ? '像被重物压住一样，不太像针扎，疼的时候还有点喘不过气。'
    : text.includes('放射') || text.includes('肩')
      ? '主要在胸骨后面，刚才左肩和左臂也有一点酸痛。'
      : text.includes('高血压') || text.includes('吸烟') || text.includes('既往')
        ? '我有高血压，平时吃药不太规律，吸烟二十多年了。'
        : text.includes('出汗') || text.includes('恶心')
          ? '发作时出了很多冷汗，也有一点恶心和气短。'
          : '我只能根据这个虚拟教学病例回答问诊问题，目前主要是胸口不舒服，也比较担心。';
  return {
    patient_reply: { role: 'patient', content: reply },
    tutor_hint: '继续补充高危鉴别诊断，并尽早提出心电图和肌钙蛋白检查。',
    scores: [
      { name: '病史采集', score: text.includes('性质') ? 82 : 68, max_score: 100, feedback: '继续补充疼痛性质、放射痛和伴随症状。' },
      { name: '检查选择', score: text.includes('心电图') || text.includes('肌钙蛋白') ? 86 : 62, max_score: 100, feedback: '疑似 ACS 时应尽早提出心电图和肌钙蛋白。' },
      { name: '鉴别诊断', score: text.includes('夹层') || text.includes('肺栓塞') ? 80 : 58, max_score: 100, feedback: '需要主动排除主动脉夹层、肺栓塞和气胸。' },
      { name: '临床决策', score: 72, max_score: 100, feedback: '建议明确急诊监护与复查路径。' },
      { name: '指南证据', score: 66, max_score: 100, feedback: '关键决策需要引用指南或教材依据。' },
      { name: '沟通表达', score: 84, max_score: 100, feedback: '表达清楚，注意安抚患者并说明检查目的。' }
    ],
    missing_points: [
      { id: 'quality', level: 'warning', text: '胸痛性质采集不完整', suggestion: '追问压榨样、撕裂样、针刺样等疼痛特征。' },
      { id: 'dissection', level: 'danger', text: '尚未排除主动脉夹层', suggestion: '询问撕裂样胸背痛、血压差和神经系统症状。' },
      { id: 'ecg', level: 'warning', text: '检查时效性不足', suggestion: '疑似 ACS 时应尽早完成心电图与心肌标志物评估。' }
    ],
    workflow_trace: fallbackWorkflow.map((stage) => ({ ...stage, status: 'done', detail: stage.goal })),
    citations: fallbackGuidelines.map((doc) => ({ id: doc.id, title: doc.title, source: doc.source, snippet: doc.content })),
    safety_notes: ['本病例为虚拟教学病例，不含真实患者信息。', '平台反馈仅用于医学教学训练，不用于真实临床诊断。']
  };
}

function selectCase(caseId: string) {
  activeCaseId.value = caseId;
  messages.value = [{ role: 'patient', content: caseId === 'emergency_chest_pain' ? '医生，我胸口疼得厉害，大概两个小时前开始的。' : '医生您好，我最近身体不舒服，想请您帮我看看。' }];
  const demo = localPatientReply('');
  scores.value = demo.scores;
  missing.value = demo.missing_points;
}

function resetTraining() {
  selectCase(activeCaseId.value);
  input.value = '';
  error.value = '';
}

function usePrompt(prompt: string) {
  input.value = prompt;
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text || loading.value) return;
  messages.value.push({ role: 'student', content: text });
  input.value = '';
  loading.value = true;
  error.value = '';
  try {
    const response = useBackend ? await sendPatientMessage(activeCaseId.value, text, messages.value) : localPatientReply(text);
    messages.value.push(response.patient_reply);
    messages.value.push({ role: 'tutor', content: response.tutor_hint });
    scores.value = response.scores;
    missing.value = response.missing_points;
  } catch (err) {
    error.value = '后端暂时不可用，已切换为本地演示反馈。';
    const response = localPatientReply(text);
    messages.value.push(response.patient_reply);
    messages.value.push({ role: 'tutor', content: response.tutor_hint });
    scores.value = response.scores;
    missing.value = response.missing_points;
  } finally {
    loading.value = false;
  }
}

function handleComposerKeydown(event: KeyboardEvent) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}

onMounted(async () => {
  try {
    const [site, caseData, guidelineData, workflowData, dashboardData, reportData, graphData] = await Promise.all([
      getOverview(), getCases(), getGuidelines(), getWorkflow(), getTeacherDashboard(),
      getTrainingReport(activeCaseId.value), getKnowledgeGraph()
    ]);
    overview.value = site;
    cases.value = caseData;
    citations.value = guidelineData;
    workflow.value = workflowData.stages;
    dashboard.value = dashboardData;
    report.value = reportData;
    kgNodes.value = graphData.nodes;
    kgEdges.value = graphData.edges;
  } catch {
    cases.value = fallbackCases;
    citations.value = fallbackGuidelines;
    workflow.value = fallbackWorkflow;
    dashboard.value = fallbackDashboard;
    report.value = fallbackReport;
    kgNodes.value = fallbackGraph.nodes;
    kgEdges.value = fallbackGraph.edges;
  }
  const demo = localPatientReply(input.value);
  scores.value = demo.scores;
  missing.value = demo.missing_points;
});
</script>

<template>
  <div class="app-layout">
    <div v-if="mobileNavOpen" class="nav-scrim" @click="mobileNavOpen = false" />
    <aside :class="['sidebar', { open: mobileNavOpen }]">
      <div class="brand-block">
        <div class="brand-mark"><Activity :size="22" /></div>
        <div><strong>临思智训</strong><span>Clinical Mind AI</span></div>
        <button class="icon-button mobile-close" type="button" title="关闭导航" @click="mobileNavOpen = false"><X :size="19" /></button>
      </div>

      <div class="workspace-label">学习空间</div>
      <nav class="side-nav" aria-label="主导航">
        <button v-for="item in navItems" :key="item.id" :class="{ active: activeView === item.id }" type="button" @click="switchView(item.id)">
          <component :is="item.icon" :size="19" />
          <span>{{ item.label }}</span>
          <ChevronRight v-if="activeView === item.id" class="nav-arrow" :size="16" />
        </button>
      </nav>

      <div class="sidebar-status">
        <div class="status-heading"><ShieldCheck :size="18" /><strong>教学安全模式</strong></div>
        <p>当前仅使用虚拟病例，不提供真实诊断。</p>
        <div class="online-row"><span class="online-dot" />系统服务正常</div>
      </div>
      <button class="help-link" type="button"><CircleHelp :size="18" />帮助与反馈</button>
    </aside>

    <main class="main-shell">
      <header class="topbar">
        <div class="topbar-left">
          <button class="icon-button mobile-menu" type="button" title="打开导航" @click="mobileNavOpen = true"><Menu :size="21" /></button>
          <div class="breadcrumb"><span>医学教育实训平台</span><ChevronRight :size="15" /><strong>{{ viewMeta[activeView].title }}</strong></div>
        </div>
        <div class="topbar-actions">
          <div class="role-switch" aria-label="角色切换">
            <button :class="{ active: role === 'student' }" type="button" @click="role = 'student'">学生端</button>
            <button :class="{ active: role === 'teacher' }" type="button" @click="role = 'teacher'; activeView = 'teacher'">教师端</button>
          </div>
          <button class="icon-button" type="button" title="通知"><Bell :size="19" /><span class="notification-dot" /></button>
          <div class="profile"><div class="avatar">林</div><div><strong>林同学</strong><span>临床医学 · 大三</span></div></div>
        </div>
      </header>

      <div class="page-content">
        <section class="page-heading">
          <div><p>{{ currentOverview.contest_track }}</p><h1>{{ viewMeta[activeView].title }}</h1><span>{{ viewMeta[activeView].subtitle }}</span></div>
          <button v-if="activeView === 'training'" class="secondary-button" type="button" @click="resetTraining"><RotateCcw :size="17" />重新开始</button>
          <button v-else-if="activeView === 'report'" class="primary-button" type="button"><FileText :size="17" />导出报告</button>
        </section>

        <template v-if="activeView === 'training'">
          <section class="progress-strip" aria-label="训练进度">
            <div v-for="(label, index) in ['接诊问诊', '完善信息', '临床决策', '总结复盘']" :key="label" :class="['progress-step', { active: currentStage === index + 1, done: currentStage > index + 1 }]">
              <span><Check v-if="currentStage > index + 1" :size="14" />{{ currentStage > index + 1 ? '' : index + 1 }}</span>
              <strong>{{ label }}</strong>
            </div>
            <div class="progress-time"><span>本次训练</span><strong>12:48</strong></div>
          </section>

          <section class="training-workspace">
            <aside class="case-browser surface">
              <div class="panel-title"><div><h2>训练病例</h2><span>{{ cases.length }} 个可用病例</span></div><Play :size="18" /></div>
              <label class="search-box"><Search :size="17" /><input v-model="caseQuery" type="search" placeholder="搜索病例或科室" /></label>
              <div class="case-stack">
                <button v-for="item in filteredCases" :key="item.id" :class="['case-item', { active: activeCaseId === item.id }]" type="button" @click="selectCase(item.id)">
                  <div class="case-icon"><Stethoscope :size="18" /></div>
                  <div><strong>{{ item.title }}</strong><span>{{ item.department }} · {{ item.difficulty }}</span><small>{{ item.chief_complaint }}</small></div>
                  <ChevronRight :size="16" />
                </button>
              </div>
            </aside>

            <section class="consultation surface">
              <div class="patient-header">
                <div class="patient-visual"><UserRound :size="29" /></div>
                <div class="patient-copy"><div><h2>{{ activeCase.title }}</h2><span class="live-badge"><span />AI 标准化病人在线</span></div><p>{{ activeCase.department }} · 主诉：{{ activeCase.chief_complaint }} · 难度：{{ activeCase.difficulty }}</p></div>
                <button class="icon-button" type="button" title="病例信息"><FileText :size="19" /></button>
              </div>
              <div class="goal-row"><span>训练目标</span><div><b v-for="goal in activeCase.learning_goals" :key="goal">{{ goal }}</b></div></div>

              <div class="chat-window">
                <div class="session-divider"><span>本次问诊开始</span></div>
                <article v-for="(message, index) in messages" :key="index" :class="['message-row', message.role]">
                  <div class="message-avatar"><UserRound v-if="message.role === 'patient'" :size="18" /><GraduationCap v-else-if="message.role === 'student'" :size="18" /><Sparkles v-else :size="18" /></div>
                  <div class="message-body"><div><strong>{{ message.role === 'student' ? '我' : message.role === 'patient' ? 'AI 标准化病人' : 'AI 导师' }}</strong><span>刚刚</span></div><p>{{ message.content }}</p></div>
                </article>
                <div v-if="loading" class="typing-indicator"><span /><span /><span />AI 病人正在组织回答</div>
              </div>

              <div class="quick-prompts"><span>快速追问</span><button v-for="prompt in quickPrompts" :key="prompt" type="button" @click="usePrompt(prompt)">{{ prompt }}</button></div>
              <div class="composer">
                <textarea v-model="input" rows="2" placeholder="输入问诊内容，按 Enter 发送，Shift + Enter 换行" @keydown="handleComposerKeydown" />
                <div class="composer-footer"><span><ShieldCheck :size="15" />医学内容由 AI 生成，请结合教学目标判断</span><button class="send-button" type="button" :disabled="loading || !input.trim()" title="发送问诊" @click="sendMessage"><Send :size="18" /></button></div>
              </div>
              <p v-if="error" class="error-text"><AlertTriangle :size="16" />{{ error }}</p>
            </section>

            <aside class="feedback-panel surface">
              <div class="score-overview"><div class="score-ring" :style="{ '--score': `${averageScore * 3.6}deg` }"><div><strong>{{ averageScore }}</strong><span>综合得分</span></div></div><div><span>实时能力评估</span><strong>{{ averageScore >= 80 ? '表现优秀' : averageScore >= 70 ? '稳步提升' : '继续练习' }}</strong><small>较上次训练 +6 分</small></div></div>
              <div class="feedback-tabs"><button :class="{ active: scoreTab === 'scores' }" type="button" @click="scoreTab = 'scores'">能力评分</button><button :class="{ active: scoreTab === 'missing' }" type="button" @click="scoreTab = 'missing'">遗漏提醒 <b>{{ missing.length }}</b></button></div>
              <div v-if="scoreTab === 'scores'" class="score-list">
                <article v-for="item in scores" :key="item.name"><div><strong>{{ item.name }}</strong><span>{{ item.score }}</span></div><progress :value="item.score" :max="item.max_score" /><p>{{ item.feedback }}</p></article>
              </div>
              <div v-else class="missing-list">
                <article v-for="item in missing" :key="item.id" :class="item.level"><AlertTriangle :size="17" /><div><strong>{{ item.text }}</strong><p>{{ item.suggestion }}</p></div></article>
              </div>
              <button class="evidence-link" type="button" @click="switchView('guidelines')"><BookOpen :size="17" />查看本病例循证依据<ChevronRight :size="16" /></button>
            </aside>
          </section>
        </template>

        <template v-else-if="activeView === 'guidelines'">
          <div class="tool-row"><label class="wide-search"><Search :size="18" /><input type="search" placeholder="搜索指南、疾病、检查或关键词" /></label><button class="filter-button" type="button">全部来源<ChevronRight :size="16" /></button></div>
          <section class="guideline-grid">
            <article v-for="doc in citations" :key="doc.id" class="guideline-card surface"><div class="document-icon"><BookOpen :size="23" /></div><span>{{ doc.type }}</span><h2>{{ doc.title }}</h2><p>{{ doc.content }}</p><div class="tag-row"><b v-for="tag in doc.tags" :key="tag">{{ tag }}</b></div><footer><span>{{ doc.source }}</span><button type="button">查看证据<ChevronRight :size="16" /></button></footer></article>
          </section>
        </template>

        <template v-else-if="activeView === 'workflow'">
          <section class="workflow-intro surface"><div><Bot :size="30" /><div><h2>一次问诊，五个 Agent 协同完成</h2><p>每个节点职责单一、输出可追踪，评分和建议均经过医学安全校验。</p></div></div><span><span class="online-dot" />工作流运行正常</span></section>
          <section class="workflow-list">
            <article v-for="(stage, index) in workflow" :key="stage.id" class="workflow-item surface"><div class="workflow-index">0{{ index + 1 }}</div><div class="workflow-icon"><Bot v-if="index === 0" :size="22" /><Search v-else-if="index === 1" :size="22" /><BarChart3 v-else-if="index === 2" :size="22" /><ShieldCheck v-else-if="index === 3" :size="22" /><FileText v-else :size="22" /></div><div><span>{{ stage.agent }}</span><h2>{{ stage.name }}</h2><p>{{ stage.goal }}</p></div><div class="workflow-state"><Check :size="15" />已完成</div></article>
          </section>
        </template>

        <template v-else-if="activeView === 'teacher'">
          <section class="metric-grid">
            <article class="metric surface"><div><Users :size="20" /></div><span>班级平均分</span><strong>{{ currentDashboard.class_average }}</strong><small>较上周 +3.2%</small></article>
            <article class="metric surface"><div><MessageSquareText :size="20" /></div><span>累计训练次数</span><strong>{{ currentDashboard.training_sessions }}</strong><small>本周新增 38 次</small></article>
            <article class="metric surface"><div><Activity :size="20" /></div><span>批改时间减少</span><strong>{{ currentDashboard.teacher_time_saved }}</strong><small>约节省 16.4 小时</small></article>
            <article class="metric surface"><div><BookOpen :size="20" /></div><span>指南引用准确率</span><strong>{{ currentDashboard.citation_accuracy }}</strong><small>较上周 +5.1%</small></article>
          </section>
          <section class="teacher-grid">
            <article class="chart-panel surface"><div class="panel-title"><div><h2>能力提升趋势</h2><span>近 6 周训练数据</span></div><button class="filter-button" type="button">临床 3 班</button></div><div class="bar-chart"><div v-for="(item, index) in currentDashboard.improvements" :key="item.label"><span>{{ item.value }}%</span><i :style="{ height: `${item.value * 4}px` }" /><b>{{ ['临床推理', '问诊完整', '循证能力'][index] }}</b></div></div></article>
            <article class="weakness-panel surface"><div class="panel-title"><div><h2>高频遗漏点</h2><span>按出现频次排序</span></div><AlertTriangle :size="19" /></div><ol><li v-for="(item, index) in currentDashboard.common_missing_points" :key="item"><span>0{{ index + 1 }}</span><strong>{{ item }}</strong><b>{{ [68, 54, 47, 35][index] }}%</b></li></ol></article>
          </section>
        </template>

        <template v-else-if="activeView === 'report'">
          <section class="report-summary surface"><div class="report-score"><strong>{{ averageScore }}</strong><span>本次训练得分</span></div><div><span>病例</span><strong>{{ activeCase.title }}</strong><small>{{ activeCase.department }} · 已完成</small></div><div><span>能力等级</span><strong>进阶</strong><small>超过 72% 的同阶段学生</small></div><div><span>建议复训</span><strong>3 天后</strong><small>巩固高危鉴别诊断</small></div></section>
          <section class="report-grid">
            <article class="report-block surface"><div class="block-title"><GitBranch :size="19" /><h2>诊断推理路径</h2></div><ol class="path-list"><li v-for="item in currentReport.diagnosis_path" :key="item"><span><Check :size="13" /></span>{{ item }}</li></ol></article>
            <article class="report-block surface"><div class="block-title success"><Check :size="19" /><h2>本次优势</h2></div><ul><li v-for="item in currentReport.strengths" :key="item">{{ item }}</li></ul></article>
            <article class="report-block surface"><div class="block-title warning"><AlertTriangle :size="19" /><h2>改进重点</h2></div><ul><li v-for="item in currentReport.improvements" :key="item">{{ item }}</li></ul></article>
            <article class="report-block surface"><div class="block-title"><Play :size="19" /><h2>推荐复训病例</h2></div><div class="recommended-list"><button v-for="item in currentReport.recommended_cases" :key="item" type="button" @click="switchView('training')"><Stethoscope :size="17" />{{ item }}<ChevronRight :size="15" /></button></div></article>
          </section>
        </template>

        <template v-else>
          <section class="graph-layout">
            <div class="graph-canvas surface"><div class="graph-legend"><span><i class="symptom" />症状</span><span><i class="disease" />疾病</span><span><i class="exam" />检查</span><span><i class="guideline" />证据</span></div><svg class="knowledge-graph" viewBox="0 0 600 420" role="img" aria-label="医学教育知识图谱"><line v-for="edge in graphEdges" :key="`${edge.source}-${edge.target}`" :x1="locate(edge.source).x" :y1="locate(edge.source).y" :x2="locate(edge.target).x" :y2="locate(edge.target).y" /><g v-for="node in graphNodes" :key="node.id" :class="node.group"><circle :cx="node.x" :cy="node.y" :r="node.id === 'chest_pain' ? 38 : 30" /><text :x="node.x" :y="node.y + 4" text-anchor="middle">{{ node.label }}</text></g></svg></div>
            <aside class="graph-detail surface"><div class="document-icon"><BrainCircuit :size="23" /></div><span>当前中心节点</span><h2>胸痛</h2><p>胸痛是急诊常见主诉，需要优先识别威胁生命的病因，并结合症状特征、危险因素和辅助检查进行分层。</p><div><b>关联节点</b><strong>{{ graphNodes.length - 1 }}</strong></div><div><b>证据关系</b><strong>{{ graphEdges.length }}</strong></div><button class="primary-button" type="button" @click="switchView('training')">进入相关病例训练</button></aside>
          </section>
        </template>
      </div>
    </main>
  </div>
</template>
